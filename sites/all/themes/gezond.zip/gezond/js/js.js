(function ($) {

    if (typeof Drupal != 'undefined') {
        Drupal.behaviors.PaintProjs = {
            attach: function (context, settings) {
//                init();
            },

            completedCallback: function () {
                // Do nothing. But it's here in case other modules/themes want to override it.
            }
        }
    }

  $(function () {
//    if (typeof Drupal == 'undefined') {
      init();
//    }
  });

  function init() {
    initBgImageChoice();
    initFancybox();
    initUniform();
  }

  function initFancybox() {

    $('.title .btn, .cols .col-3 a').fancybox({
      width: 753,
      height: 'auto',
      autoSize: false,
      autoResize: false
    });

    fancyboxLoad();

    function fancyboxLoad() {
      if(location.hash.length > 0 && location.hash == '#b-form-registration') {
        $.fancybox.open('#b-form-registration', {
          width: 753,
          height: 'auto',
          autoSize: false,
          autoResize: false
        });
      }
    }

    $(window).on('hashchange', fancyboxLoad);
  }

  function initUniform() {
    $('.form-file, .form-checkbox').uniform({
      fileButtonHtml: 'Upload Logo'
    });

    var $uploader = $('.uploader');

    $('.form-file').on('mouseout', function() {
      if($uploader.find('.filename').text() !== 'No file selected') {
        $uploader.addClass('uploader-processed');
      } else {
        $uploader.removeClass('uploader-processed');
      }
    });
  }

  function initBgImageChoice() {
    var $wrapper = $('.outer-wrapper'),
      time = (new Date()).getSeconds();

    if(time % 2) $wrapper.addClass('style-b');
  }

})(jQuery);